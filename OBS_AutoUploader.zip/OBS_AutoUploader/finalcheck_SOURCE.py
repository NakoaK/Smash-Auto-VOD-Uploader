"""
FinalCheck.py

Options:
    --dry-run   Also attempt a simple YouTube API call to verify OAuth + API access
"""

import os
import sys
import argparse

print("Needed packages and files are being checked. If the youtube PICKLE token is not found, you will be launched to google cloud console to login...")

# Prompt the user to press Enter to continue
input("Press the <ENTER> key to continue...")

REQUIRED_FILES = [
    "client_secret.json",
    "obs_trigger.py",
    "youtube_uploader.py",
]

REQUIRED_PACKAGES = [
    "googleapiclient.discovery",
    "google_auth_oauthlib.flow",
    "google.auth.transport.requests",
]

# Simple ANSI color helper (works in modern Windows terminals)
if sys.stdout.isatty():
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    CYAN = "\033[96m"
    RESET = "\033[0m"
else:
    GREEN = YELLOW = RED = CYAN = RESET = ""


def print_header(text):
    print(f"{CYAN}=== {text} ==={RESET}")


def check_python_version():
    print_header("Python Version")
    print(sys.version)
    major, minor = sys.version_info[:2]
    if major == 3:
        print(f"{GREEN}[OK]{RESET} Python 3.{minor} detected.")
    else:
        print(f"{YELLOW}[WARN]{RESET} This is not Python 3. OBS scripting typically requires Python 3.x.")
    print()


def check_required_files(base_dir):
    print_header("Required Files")
    everything_ok = True
    for fname in REQUIRED_FILES:
        path = os.path.join(base_dir, fname)
        if os.path.isfile(path):
            print(f"{GREEN}[OK]{RESET} {fname} found at {path}")
        else:
            print(f"{RED}[MISSING]{RESET} {fname} not found in {base_dir}")
            everything_ok = False
    print()
    return everything_ok


def check_packages():
    print_header("Python Package Imports")
    everything_ok = True
    for pkg in REQUIRED_PACKAGES:
        root = pkg.split(".")[0]
        try:
            __import__(root)
            print(f"{GREEN}[OK]{RESET} {pkg} import succeeded")
        except ImportError as e:
            print(f"{RED}[MISSING]{RESET} Could not import {pkg}: {e}")
            everything_ok = False
    print()
    return everything_ok


def dry_run_youtube_test(base_dir):
    """
    Optional: verify that we can create a YouTube API client and
    make a simple 'channels().list(mine=True)' call.
    This will:
      - Use client_secret.json
      - Trigger a browser login the first time (OAuth)
      - Consume a tiny amount of API quota
    """
    print_header("YouTube API Dry-Run Test")

    # import here to avoid errors if packages missing and dry-run not requested
    from googleapiclient.discovery import build
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request
    import google.auth.exceptions
    import pickle

    CLIENT_SECRETS_FILE = os.path.join(base_dir, "client_secret.json")
    TOKEN_FILE = os.path.join(base_dir, "youtube_token.pickle")
    SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]

    if not os.path.isfile(CLIENT_SECRETS_FILE):
        print(f"{RED}[ERROR]{RESET} client_secret.json not found at {CLIENT_SECRETS_FILE}")
        return False

    creds = None
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, "rb") as token:
            creds = pickle.load(token)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except google.auth.exceptions.RefreshError:
                creds = None
        if not creds:
            print("Opening browser for YouTube OAuth login...")
            flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRETS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
        with open(TOKEN_FILE, "wb") as token:
            import pickle as _pickle
            _pickle.dump(creds, token)

    try:
        youtube = build("youtube", "v3", credentials=creds)
        request = youtube.channels().list(part="snippet", mine=True, maxResults=1)
        response = request.execute()
        items = response.get("items", [])
        if items:
            title = items[0]["snippet"]["title"]
            print(f"{GREEN}[OK]{RESET} YouTube API call succeeded. Channel: {title}")
        else:
            print(f"{YELLOW}[WARN]{RESET} API call succeeded, but no channel data returned.")
        print()
        return True
    except Exception as e:
        print(f"{RED}[ERROR]{RESET} YouTube API dry-run failed: {e}")
        print()
        return False


def main():
    parser = argparse.ArgumentParser(description="Check environment for OBS Auto Uploader.")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Also perform a simple YouTube API test (OAuth + channels().list)."
    )
    args = parser.parse_args()

    base_dir = os.path.dirname(os.path.abspath(__file__))

    print("==============================================")
    print(" OBS Auto Uploader Environment Check")
    print(" Folder:", base_dir)
    print("==============================================")
    print()

    check_python_version()
    files_ok = check_required_files(base_dir)
    pkgs_ok = check_packages()

    youtube_ok = True
    if args.dry_run and files_ok and pkgs_ok:
        youtube_ok = dry_run_youtube_test(base_dir)
    elif args.dry_run:
        print(f"{YELLOW}[WARN]{RESET} Skipping YouTube dry-run because files or packages are missing.\n")

    if files_ok and pkgs_ok and youtube_ok:
        print(f"{GREEN}✅ Environment looks good!{RESET}")
        print("You should now be able to use obs_trigger.py from OBS.")
    else:
        print(f"{YELLOW}⚠ Some issues were found above.{RESET}")
        print("Fix the [MISSING]/[ERROR] items, then re-run this check.")
    print()


if __name__ == "__main__":
    main()
