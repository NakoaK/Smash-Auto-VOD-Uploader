# Screipt aimed to Auto-upload last recording to YouTube using metadata scraped from scene text sources in OBS

import obspython as obs # type: ignore
import subprocess
import os
import json

# Variables passed through OBS Script UI
python_exe = ""        # Path to python.exe
uploader_script = ""   # Path to youtube_uploader.py
auto_enabled = True

# Tournament metadata
p1_source_name = "P1_Name"
p2_source_name = "P2_Name"
round_source_name = "Round"
tournament_source_name = "Tournament"
character1_source_name = "P1_Char"
character2_source_name = "P2_Char"


def script_description():
    return "Auto-upload last recording to Youtube with auto-generated tournament data."


def script_properties():
    fields = obs.obs_properties_create()

    obs.obs_properties_add_bool(fields, "auto_enabled", "Enable Auto Upload")

    obs.obs_properties_add_path(
        fields, "python_exe", "Python Executable",
        obs.OBS_PATH_FILE, "", ""
    )
    obs.obs_properties_add_path(
        fields, "uploader_script", "Uploader Script (youtube_uploader.py)",
        obs.OBS_PATH_FILE, "", ""
    )

    obs.obs_properties_add_text(fields, "p1_source_name", "P1 name", obs.OBS_TEXT_DEFAULT)
    obs.obs_properties_add_text(fields, "p2_source_name", "P2 name", obs.OBS_TEXT_DEFAULT)
    obs.obs_properties_add_text(fields, "round_source_name", "Round name", obs.OBS_TEXT_DEFAULT)
    obs.obs_properties_add_text(fields, "tournament_source_name", "Tournament name", obs.OBS_TEXT_DEFAULT)
    obs.obs_properties_add_text(fields, "character1_source_name", "Character 1 name", obs.OBS_TEXT_DEFAULT)
    obs.obs_properties_add_text(fields, "character2_source_name", "Character 2 name", obs.OBS_TEXT_DEFAULT)

    return fields


def script_update(settings):
    global auto_enabled, python_exe, uploader_script
    global p1_source_name, p2_source_name, round_source_name, tournament_source_name, character1_source_name, character2_source_name

    # Software data
    auto_enabled = obs.obs_data_get_bool(settings, "auto_enabled")
    python_exe = obs.obs_data_get_string(settings, "python_exe")
    uploader_script = obs.obs_data_get_string(settings, "uploader_script")


    # Text data
    p1_source_name = obs.obs_data_get_string(settings, "p1_source_name") or "P1_Name"
    p2_source_name = obs.obs_data_get_string(settings, "p2_source_name") or "P2_Name"
    round_source_name = obs.obs_data_get_string(settings, "round_source_name") or "Round"
    tournament_source_name = obs.obs_data_get_string(settings, "tournament_source_name") or "Tournament"
    character1_source_name = obs.obs_data_get_string(settings, "character1_source_name") or ""
    character2_source_name = obs.obs_data_get_string(settings, "character2_source_name") or ""


def script_load(settings):
    obs.obs_frontend_add_event_callback(on_event)


def script_unload():
    obs.obs_frontend_remove_event_callback(on_event)


def on_event(event):
    if event == obs.OBS_FRONTEND_EVENT_RECORDING_STOPPED and auto_enabled:
        trigger_upload()


def trigger_upload():
    global python_exe, uploader_script

    if not python_exe or not os.path.isfile(python_exe):
        obs.script_log(obs.LOG_ERROR, "Python executable not set or invalid.")
        return

    if not uploader_script or not os.path.isfile(uploader_script):
        obs.script_log(obs.LOG_ERROR, "Uploader script path not set or invalid.")
        return

    last_video = obs.obs_frontend_get_last_recording()
    if not last_video or not os.path.isfile(last_video):
        obs.script_log(obs.LOG_WARNING, "No valid last recording found.")
        return

    metadata = collect_metadata_from_scene()
    if not metadata:
        obs.script_log(obs.LOG_WARNING, "Failed to collect metadata from scene.")
        return

    uploader_dir = os.path.dirname(uploader_script)
    meta_path = os.path.join(uploader_dir, "metadata.json")

    try:
        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)
    except Exception as e:
        obs.script_log(obs.LOG_ERROR, "Failed to write metadata.json: {}".format(e))
        return

    # --- NEW: launch uploader with no visible console window on Windows ---
    try:
        creationflags = 0
        if os.name == "nt":
            import subprocess as _sub
            creationflags = _sub.CREATE_NO_WINDOW

            _sub.Popen(
                [python_exe, uploader_script, last_video, meta_path],
                creationflags=creationflags
            )
        else:
            # Non-Windows: normal spawn (no console popup issue)
            subprocess.Popen([python_exe, uploader_script, last_video, meta_path])

        obs.script_log(obs.LOG_INFO, "Started uploader for: {}".format(last_video))
    except Exception as e:
        obs.script_log(obs.LOG_ERROR, "Failed to start uploader: {}".format(e))


def collect_metadata_from_scene():
    """Read text values from configured text sources in the current program scene."""
    scene_source = obs.obs_frontend_get_current_scene()
    if scene_source is None:
        return None

    try:
        scene = obs.obs_scene_from_source(scene_source)
        if scene is None:
            return None

        def get_text_from_scene(source_name):
            if not source_name:
                return ""
            item = obs.obs_scene_find_source(scene, source_name)
            if item is None:
                return ""
            src = obs.obs_sceneitem_get_source(item)
            if src is None:
                return ""
            settings = obs.obs_source_get_settings(src)
            try:
                # Text (GDI+) uses "text" for its content
                return obs.obs_data_get_string(settings, "text") or ""
            finally:
                obs.obs_data_release(settings)

        p1 = get_text_from_scene(p1_source_name) or "BBW"
        p2 = get_text_from_scene(p2_source_name) or "The Chancellor"
        rnd = get_text_from_scene(round_source_name) or "Super Mega Grand Finals"
        tourney = get_text_from_scene(tournament_source_name) or "EVO 2019"
        char1 = get_text_from_scene(character1_source_name) or "Diddy Kong"
        char2 = get_text_from_scene(character1_source_name) or "ROB"

        metadata = {
            "tournament_name": tourney,
            "player1": p1,
            "player2": p2,
            "round": rnd,
            "game": "Super Smash Bros. Ultimate",
            "character1": char1,
            "character2": char2,
            "privacy_status": "public",
            "auto_tags": [
                "Python Script by Sage Severson",
                "Smash Bros",
                "Smash Ultimate",
                "Tournament",
                p1,
                p2,
                tourney,
                rnd
            ]
        }
        return metadata

    finally:
        obs.obs_source_release(scene_source)
