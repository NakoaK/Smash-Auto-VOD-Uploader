# youtube_uploader.py
# python youtube_uploader.py <video_path> [metadata_path]
#
#
# Duration detection:
# Tries ffprobe (from ffmpeg) if available for precise duration.
# If ffprobe isn't available, skips the duration check and checks file size for estimation

import os
import sys
import json
import datetime
import pickle
import subprocess
import time

from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request

CLIENT_SECRETS_FILE = "client_secret.json"
TOKEN_FILE = "youtube_token.pickle"
SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]

# --- BASE DIRECTORY (for OBS) ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CLIENT_SECRETS_FILE = os.path.join(BASE_DIR, "client_secret.json")
TOKEN_FILE = os.path.join(BASE_DIR, "youtube_token.pickle")
LOG_FILE = os.path.join(BASE_DIR, "uploader_debug.log")

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]

# --- CONFIGURABLE SETTINGS ---

# Minimum duration (in seconds) required to upload.
# Clips shorter than this will be kept locally but NOT uploaded.
MIN_DURATION_SECONDS = 5

# Default audience and visibility
DEFAULT_SELF_DECLARED_MADE_FOR_KIDS = False 
DEFAULT_PRIVACY_STATUS = "public"            # public, unlisted, private
DEFAULT_CATEGORY_ID = "20"                     # 20 = Gaming

# Rough estimate video size
ESTIMATED_SECONDS_PER_MB = 11.0

# -----------------------------


def get_video_duration_seconds_ffprobe(video_path):
    """
    Try to get video duration using ffprobe (part of ffmpeg).
    If ffprobe is not available or fails, return None.
    """
    try:
        cmd = [
            "ffprobe",
            "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            video_path,
        ]
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
        )
        duration_str = result.stdout.strip()
        if duration_str:
            return float(duration_str)
    except Exception as e:
        print(f"[uploader] Could not determine duration via ffprobe: {e}")

    return None  # Unknown duration from ffprobe


def estimate_duration_from_filesize(video_path):
    """
    Fallback: estimate duration from file size using a rough average.
    """
    size_bytes = os.path.getsize(video_path)
    size_mb = size_bytes / (1024 * 1024)
    est_seconds = size_mb * ESTIMATED_SECONDS_PER_MB
    print(f"[uploader] Approximated duration from file size: {est_seconds:.2f} seconds "
          f"(size {size_mb:.2f} MB)")
    return est_seconds


def get_estimated_duration(video_path):
    """
    Try ffprobe first. If unavailable/fails, fall back to file-size estimate.
    Always returns a float value in seconds.
    """
    duration = get_video_duration_seconds_ffprobe(video_path)
    if duration is not None:
        print(f"[uploader] Precise duration from ffprobe: {duration:.2f} seconds")
        return duration

    # Fallback: estimate from file size
    return estimate_duration_from_filesize(video_path)



def load_metadata(meta_path):
    if meta_path and os.path.isfile(meta_path):
        with open(meta_path, "r", encoding="utf-8") as f:
            meta = json.load(f)
    else:
        meta = {}

    meta.setdefault("tournament_name", "Tournament")
    meta.setdefault("player1", "Player 1")
    meta.setdefault("player2", "Player 2")
    meta.setdefault("round", "Bracket")
    meta.setdefault("game", "Super Smash Bros. Ultimate")
    meta.setdefault("character1", "Broken Character 1")
    meta.setdefault("character2", "Broken Character 2")
    meta.setdefault("privacy_status", DEFAULT_PRIVACY_STATUS)
    meta.setdefault("auto_tags", ["Smash Bros", "Tournament", "OBS Auto Upload by Sage Severson"])
    meta.setdefault("self_declared_made_for_kids", DEFAULT_SELF_DECLARED_MADE_FOR_KIDS)

    return meta


def generate_metadata(video_path, meta):
    base = os.path.basename(video_path)
    timestamp = datetime.datetime.now().strftime("%m-%d-%Y")

    title = f"{meta['tournament_name']}: {meta['round']} - {meta['player1']} vs {meta['player2']}"

    description = f"""
{meta['tournament_name']}:
{meta['round']}
{meta['player1']} - {meta['character1']}
{meta['player2']} - {meta['character2']}

Recorded: {timestamp}

Game: {meta.get('game', 'Super Smash Bros. Ultimate')}

    """

    tags = meta.get("auto_tags", [])
    privacy = meta.get("privacy_status", DEFAULT_PRIVACY_STATUS)

    return title.strip(), description.strip(), tags, privacy


def get_youtube_service():
    creds = None
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, "rb") as token:
            creds = pickle.load(token)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                CLIENT_SECRETS_FILE, SCOPES
            )
            creds = flow.run_local_server(port=0)
        with open(TOKEN_FILE, "wb") as token:
            pickle.dump(creds, token)

    return build("youtube", "v3", credentials=creds)


def upload_video(video_path, meta_path=None):
    if not os.path.isfile(video_path):
        print(f"[uploader] File not found: {video_path}")
        return

    meta = load_metadata(meta_path)

    # --- Auto-skip short clips ---
    duration = get_estimated_duration(video_path)
    if duration < MIN_DURATION_SECONDS:
        print(
            f"[uploader] Clip is estimated at {duration:.2f} seconds, "
            f"which is shorter than {MIN_DURATION_SECONDS} seconds."
        )
        print("[uploader] Skipping upload but keeping the file.")
        return

    title, description, tags, privacy = generate_metadata(video_path, meta)
    made_for_kids = bool(meta.get("self_declared_made_for_kids", DEFAULT_SELF_DECLARED_MADE_FOR_KIDS))

    youtube = get_youtube_service()

    body = {
        "snippet": {
            "title": title,
            "description": description,
            "tags": tags,
            "categoryId": DEFAULT_CATEGORY_ID,
        },
        "status": {
            "privacyStatus": privacy,
            # Explicit audience declaration for YouTube "made for kids" checks.
            "selfDeclaredMadeForKids": made_for_kids,
        }
    }

    media = MediaFileUpload(video_path, chunksize=-1, resumable=True)
    request = youtube.videos().insert(
        part="snippet,status",
        body=body,
        media_body=media
    )

    response = None
    while response is None:
        status, response = request.next_chunk()
        if status:
            print(f"[uploader] Upload progress: {int(status.progress() * 100)}%")

    print("[uploader] Upload completed! Video ID:", response.get("id"))


def main():
    if len(sys.argv) < 2:
        print("Usage: python youtube_uploader.py <video_path> [metadata_path]")
        return

    video_path = sys.argv[1]
    meta_path = sys.argv[2] if len(sys.argv) > 2 else None
    upload_video(video_path, meta_path)


if __name__ == "__main__":
    main()

# time.sleep(5) # Pauses for 5 seconds
